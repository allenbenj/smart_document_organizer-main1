# ChromaDB Memory MCP Server (Codex Ready)

This is a Codex-compatible MCP server that provides semantic memory using:

- ChromaDB (vector database)
- Ollama (local embeddings)
- MCP (Model Context Protocol)

No cloud APIs required.

---

## Prerequisites

1. Node.js 18+
2. ChromaDB running locally:
   docker run -d --name chromadb -p 8100:8000 chromadb/chroma:latest

3. Ollama running locally:
   ollama pull nomic-embed-text

4. A populated ChromaDB collection

---

## Installation

Unzip the folder.

Inside the directory:

npm install
npx tsc

Edit server.ts and replace:
YOUR_COLLECTION_ID

Then build again:
npx tsc

---

## Add to Codex / MCP Config

Example:

{
  "mcpServers": {
    "chromadb-memory": {
      "command": "node",
      "args": ["E:/mcp/chromadb-memory-mcp/server.js"]
    }
  }
}

---

## Usage

Tool name:
chromadb_search

Input:
{
  "query": "your semantic search query"
}

Returns:
List of matching memory documents above similarity threshold.

---

## Configuration Options (Edit in server.ts)

CHROMA_URL
COLLECTION_ID
OLLAMA_URL
EMBEDDING_MODEL
MIN_SCORE

---

This replaces the OpenClaw plugin system and works directly with Codex MCP.
