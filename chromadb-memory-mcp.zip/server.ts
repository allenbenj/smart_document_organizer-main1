
import fetch from "node-fetch";
import { Server } from "@modelcontextprotocol/sdk/server";

const server = new Server({
  name: "chromadb-memory",
  version: "1.0.0"
});

// ----- CONFIG -----
const CHROMA_URL = "http://localhost:8100";
const COLLECTION_ID = "YOUR_COLLECTION_ID";
const OLLAMA_URL = "http://localhost:11434";
const EMBEDDING_MODEL = "nomic-embed-text";
const MIN_SCORE = 0.5;
// ------------------

async function embed(text: string) {
  const res = await fetch(`${OLLAMA_URL}/api/embeddings`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: EMBEDDING_MODEL,
      prompt: text
    })
  });

  const json: any = await res.json();
  return json.embedding;
}

async function queryChroma(embedding: number[]) {
  const res = await fetch(
    `${CHROMA_URL}/api/v1/collections/${COLLECTION_ID}/query`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query_embeddings: [embedding],
        n_results: 3
      })
    }
  );

  return await res.json();
}

server.tool(
  "chromadb_search",
  {
    description: "Semantic search over ChromaDB memory",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" }
      },
      required: ["query"]
    }
  },
  async ({ query }) => {
    const embedding = await embed(query);
    const results: any = await queryChroma(embedding);

    const docs = results.documents?.[0] ?? [];
    const distances = results.distances?.[0] ?? [];

    const filtered = docs
      .map((doc: string, i: number) => ({
        doc,
        score: 1 - distances[i]
      }))
      .filter((r: any) => r.score >= MIN_SCORE);

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(filtered, null, 2)
        }
      ]
    };
  }
);

server.listen();
